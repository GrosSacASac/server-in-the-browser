/*customserver.js*/
/*index.js server*/
"use strict";

const PORT = process.env.PORT || 8080;


const express = require("express");
const app = express();


const server = require("http").Server(app);


const state = {
    
};
let allText = "";

const start = port => {

    app.get("/", (request, response) => {
        response.sendFile(`${__dirname}/index.html`);
    });

    app.get("/js.js", (request, response) => {
        response.sendFile(`${__dirname}/js.js`);
    });        
    
    app.post("/post", (request, response) => {
        console.log("/post", request.body);
        const requestbody = request.body;
        allText += requestbody;
        response.end(requestbody);
    });    

    
    server.listen(port);

    console.log(`Server running at http://127.0.0.1:${port}/`);
}


start(PORT);
