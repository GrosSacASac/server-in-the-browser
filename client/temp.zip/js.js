"use strict";
const textareaElement = document.getElementById("1");
const paragraphElement = document.getElementById("2");
const postButtonElement = document.getElementById("3");

postButtonElement.addEventListener("click", function (event) {
    const text = String(textareaElement.value);
    textareaElement.value = "";

    const input = "post";
    const options = {
        method: "POST",
        body: text 
    };
    fetch(input, options).then(function (response) {
        return response.text();
    }).then(function(responsetext) {
        paragraphElement.textContent += responsetext;
    });
}, false);